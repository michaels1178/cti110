#This program performs a leap year check from user input
#CTI-110
#10.19 LAB - Leap Year
#Michael A. Simmons
#October 24, 2022
#
# Program gets all input from user
# Program recognizes a leap year must be divisible by 4 
# Program outputs results of leap year Check

is_leap_year = False
   
input_year = int(input())

if input_year % 4 == 0 and input_year % 100 != 0:
    print(input_year, '- leap year')
elif input_year % 400 == 0:
    print(input_year, '- leap year')
elif input_year % 100 ==0:
    print(input_year, '- not a leap year')
else:
    print(input_year, '- not a leap year')